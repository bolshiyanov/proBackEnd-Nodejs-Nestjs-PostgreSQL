## Не забудь звезду

в файле .development.env конфигурация для бд. Добавить свою.

#### npm run start:dev - Запуск

##

#### docker-compose up 
